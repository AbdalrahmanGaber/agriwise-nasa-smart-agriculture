# Field Shift — Technical Analysis Report

**Project:** Field Shift (internal brand: "AgriWise") — NASA Space Apps Challenge 2026, Challenge 7 "Adapting Farms with NASA Data", target region: Egypt.
**Scope of this report:** analysis only. No new features were implemented. Every claim below was verified by actually running the code.

---

## 1. Executive summary

Field Shift is a complete, working, bilingual (EN/AR) agricultural decision-support web app. It is NOT a skeleton or a demo: all seven core engines are fully implemented, all API endpoints respond correctly with live NASA POWER data, the production build passes, and the four engine test scripts pass against real data (Luxor, Egypt).

The two archives contain **byte-identical source code**. The GitHub version is a correct, clean superset-for-release: it adds `README.md`, `.env.example`, and a hardened `.gitignore`; the original adds only runtime artifacts (`.env`, `.git`, `db/custom.db`, `.zscripts/`, `tool-results/`) — none of which are needed, and none of which contain secrets (`.env` holds only `DATABASE_URL`).

The codebase is in good shape. The main findings are: (1) TypeScript type-checking is disabled project-wide (`ignoreBuildErrors: true`) and there are 13 real type errors hiding behind it; (2) sandbox scaffolding files (`examples/`, `tests/`, `download/`) reference missing dependencies and should be removed from the GitHub deliverable; (3) the project brand is inconsistent ("FieldShift" in README vs "AgriWise" in UI/metadata/UA strings); (4) several installed dependencies are unused.

**Verified state: install OK, build OK, all engines pass their tests, all API endpoints functional, no secrets, no placeholder/TODO debris.**

---

## 2. Archive comparison

Verified with `diff -rq` across both extracted trees (excluding runtime artifacts):

| Item | Original `.tar` | GitHub `.zip` | Verdict |
|---|---|---|---|
| `src/**` (all code) | present | **byte-identical** | no divergence |
| `prisma/schema.prisma`, configs, `bun.lock` | present | **byte-identical** | no divergence |
| `public/` (logo, images, robots.txt) | present | **byte-identical** | no divergence |
| `scripts/test-*.ts` (4 engine tests) | present | **byte-identical** | no divergence |
| `.env` | present (only `DATABASE_URL`, a file path — no secrets) | absent | correct removal |
| `.env.example` | absent | present (`DATABASE_URL="file:./db/custom.db"`) | correct addition |
| `.git` | present — 3 commits (initial + 2 sandbox UUID commits), no remote | absent | correct removal |
| `db/custom.db` | present (SQLite, 1 table `SavedAnalysis`, 2 rows) | absent, `.gitignore` now excludes `/db/*.db` | correct removal |
| `.zscripts/` (sandbox runtime scripts, `dev.pid`) | present | absent | correct removal |
| `tool-results/` (5 cached tool outputs) | present | absent | correct removal |
| `README.md` | absent | present (Bun-based setup, build, notes) | correct addition |

Conclusion: the GitHub version is the **reference version** to develop against. Nothing functional is missing from it.

---

## 3. Architecture

```
┌───────────────────────────── Browser ─────────────────────────────┐
│  src/app/page.tsx  →  LanguageProvider → AppShell                 │
│    useHashRouter (hash-based SPA: #/home, #/analyze, …)           │
│    10 views (client components; heavy views dynamic-imported)     │
│    Zustand stores (sessionStorage): useAnalysisStore,             │
│      useToolsStore · LanguageContext (localStorage, RTL)          │
└──────────────────────────────┬─────────────────────────────────────┘
                               │ fetch (JSON)
┌──────────────────────────────▼─────────────────────────────────────┐
│  Next.js 16 App Router API routes (src/app/api/*)                 │
│    zod validation → orchestration → pure engines (src/lib)        │
│    server-side fetch with User-Agent, timeouts, retries, cache    │
└──────┬───────────────────────┬──────────────────────┬──────────────┘
       │                       │                      │
┌──────▼──────┐  ┌─────────────▼──────────────┐  ┌────▼─────────────┐
│ src/lib     │  │ External services          │  │ Prisma + SQLite  │
│ pure engines│  │ NASA POWER daily/climatology│  │ (optional)       │
│ (bilingual  │  │ NASA GIBS WMTS tiles       │  │ SavedAnalysis    │
│  outputs)   │  │ Open-Meteo forecast/elev.  │  └──────────────────┘
└─────────────┘  │ Nominatim (OSM) geocoding  │
                 └────────────────────────────┘
```

Key architectural decisions (all intentional and documented in code comments):

- **Single Next route + hash router.** `useHashRouter.ts` maps `#/view` → one of 10 views; the browser back button works. All views live under `src/components/agriwise/views/`.
- **Pure, server-side engines.** `engine.ts`, `planting.ts`, `irrigation.ts`, `risk.ts`, `yield.ts`, `calendar.ts`, `fao56.ts` are dependency-free, deterministic, and produce **bilingual** output (`Bilingual = {en, ar}`) with per-factor explanations. This makes them unit-testable (see `scripts/test-*.ts`).
- **Honest-data discipline.** NASA POWER fill value `-999` is excluded; nothing is ever synthesized for missing data; unavailable factors are *excluded and their weight redistributed* (confidence drops); forecast data is always labelled as forecast; model estimates are labelled as such. This rule is applied consistently across every engine and API route.
- **State split.** `useAnalysisStore` (location/farm/result of the main analysis) and `useToolsStore` (planting/irrigation/yield/satellite results + shared location) persist to `sessionStorage` so views survive navigation/reload, and the Action Center aggregates results the farmer actually ran.
- **i18n.** Two layers: (a) a 1,150-key typed dictionary (`translations.ts`, `ar` must structurally match `en` — enforced at type level), and (b) `Bilingual` objects emitted by engines. `LanguageContext` uses `useSyncExternalStore`; a pre-hydration script in `layout.tsx` sets `lang`/`dir` before paint to avoid an RTL flash.
- **Optional persistence.** The app is fully functional without the database; `SavedAnalysis` only stores saved results.

---

## 4. Technology stack

| Layer | Technology |
|---|---|
| Framework | Next.js 16.1.1 (App Router, `output: "standalone"`) |
| Runtime | Bun 1.3.x (`bun.lock`; dev/start scripts assume Bun) |
| UI | React 19, TypeScript 5 (strict, `noImplicitAny: false`), Tailwind CSS 4, shadcn/ui (~50 Radix-based components in `src/components/ui`), `next-themes` (light/dark), framer-motion, lucide-react |
| Maps | Leaflet 1.9.4 + react-leaflet 5 (OSM tiles + NASA GIBS WMTS tile layers) |
| Charts | Recharts 2 (ClimateCharts: temperature/rain/solar/humidity/wind) |
| Forms/validation | react-hook-form + zod 4 (client form + server route validation) |
| State | Zustand 5 (2 persisted stores), custom `useSyncExternalStore` language store |
| DB | Prisma 6 + SQLite (`db/custom.db`, `DATABASE_URL`) |
| i18n | Custom bilingual system (no next-intl usage despite the dependency being installed) |
| Testing | Bun-run script tests (`scripts/test-*.ts`); no CI, no test framework |

---

## 5. Existing features and implementation status

| # | Feature | Implementation | Status |
|---|---|---|---|
| 1 | **Farm location selection** — GPS, place search, draggable map; reverse geocoding; shared across tools | `AnalyzeView` (4-step wizard: location → confirm → farm form → analyzing), `LocationPicker`, `FarmMap`, `/api/geocode` | Complete, verified |
| 2 | **Crop recommendation engine** — weighted, explainable scoring of 7 crops (temp 30%, water 20%, solar 15%, soil 15%, season 10%, humidity 5%, wind 5%); weight redistribution for unavailable data; confidence rating; per-crop factor breakdown with reasons/limitations; irrigation gap | `engine.ts`, `crops.ts`, `/api/analyze`, `ResultsView` | Complete, verified live (Luxor test passed) |
| 3 | **Climate profile & charts** — 365-day NASA POWER aggregation into monthly climatology + annual/season summary + extremes + coverage; Recharts visualizations | `nasa.ts` (`aggregateMonthly`, `summarize`), `ClimateCharts.tsx` | Complete, verified |
| 4 | **Climate risk dashboard** — 7 risk types (heat, cold, drought, rainfall-pattern, crop-range, radiation, wind) with level, measured value, documented threshold, impact, recommendations, provenance labels; **forecast-based early warnings** (heat/cold/rain/wind) | `risk.ts`, `RiskDashboard.tsx`, `/api/forecast` | Complete, verified (test script passed) |
| 5 | **Smart crop calendar** — per-crop 6-stage growth templates (planting → germination → vegetative → development → maturation → harvest) with stage spans, water shares, activities, and NASA-adapted climate notes per stage | `calendar.ts` (7 full stage templates), `CropCalendarSection.tsx` | Complete, verified |
| 6 | **Planting time advisor** — "plant now / wait / not recommended" from 25-yr climatology + 3-yr daily means + 60-day recent observations + 7-day forecast; 12-month suitability scores; season assessment; Arabic-normalized crop search with aliases | `planting.ts`, `/api/planting`, `PlantingView` | Complete, verified live |
| 7 | **Irrigation advisor** — FAO-56 Penman–Monteith ETo (Eq. 6–47, monthly + recent-observations basis), ETc = Kc × ETo with FAO-56 Table 12 Kc values and Table 11 stage lengths for all 7 crops; Open-Meteo elevation; honest disclosures (no soil-moisture claims, no application-depth prescription) | `fao56.ts`, `irrigation.ts`, `/api/irrigation`, `IrrigationView` | Complete, verified (FAO-56 Example 18 test passed) |
| 8 | **Yield reference tool** — FAOSTAT Egypt national yields (2022–2024) embedded with source labels; area arithmetic (feddan 0.42 ha); climate risk factors positioned against the crop cycle; explicit "not a field prediction" disclaimers | `yield.ts`, `/api/yield`, `YieldView` | Complete, verified |
| 9 | **Satellite monitoring** — NASA GIBS WMTS layers (VIIRS SNPP true color daily 375 m; MODIS Terra true color daily 250 m; MODIS NDVI 16-day composite) with date picker, NDVI 16-day snapping, tile availability probe (byte-size heuristic), custom SVG pin; Sentinel-2 explicitly declared unavailable; Landsat excluded after live testing | `satellite.ts`, `SatelliteView` | Complete, verified layer catalog; live tiles not fetched in this sandbox |
| 10 | **Farmer Action Center** — aggregates real results from all tools (session), ranked priority cards, empty state | `ActionCenterView.tsx`, `toolsStore.ts` | Complete |
| 11 | **Saved analyses (optional)** — save/list/load full analysis results | `/api/analyses`, Prisma `SavedAnalysis` | Complete, verified save+list live |
| 12 | **Bilingual EN/AR + RTL** — full dictionary, dir switching pre-paint, RTL-safe map handling (map stays LTR internally) | `LanguageContext.tsx`, `translations.ts` | Complete |
| 13 | **Light/dark theme** | `next-themes`, oklch tokens (warm paper/deep green light; green-black dark) | Complete |
| 14 | **Responsive design** | 124 `sm:` / 11 `md:` / 48 `lg:` breakpoint usages across views; mobile menu in Navbar | Complete (code-level; manual device QA recommended) |
| 15 | **Data sources page** — documents every provider, parameter, unit and reference key | `SourcesView.tsx` | Complete |

Crop database: **7 crops** (sugarcane, wheat, maize, rice, tomato, potato, onion) with documented FAO EcoCrop / FAO I&D Paper 33 / FAO-56 / MALR ranges, bilingual growth/limitation notes and reference keys. Explicitly designed to be extended by appending records.

---

## 6. API endpoints

All routes are server-side (`src/app/api/*/route.ts`), zod-validated, and return typed JSON. Verified live:

| Endpoint | Method | Purpose | Input (summary) | Verified result |
|---|---|---|---|---|
| `/api/analyze` | POST | Full farm analysis | location (lat/lng/label/source) + farm (soil, water, season, size, irrigation) | 200 with full `AnalysisResult` |
| `/api/planting` | POST | Planting-time advisory | crop (id or free text, EN/AR), lat/lng, currentMonth 1–12, variety? | 200 with 12-month scores + decision |
| `/api/irrigation` | POST | ETo/ETc irrigation guidance | crop, lat/lng, growthStage, soilType?, waterAvailability?, currentMonth, currentDayOfYear | 200; ETo gracefully null when elevation service unreachable |
| `/api/yield` | POST | FAOSTAT reference yields + risks | crop, lat/lng, area?, areaUnit? (incl. `feddan`), plantingMonth? | 200 |
| `/api/forecast` | GET | 7-day forecast (30-min server cache) | `?lat=&lng=` | 502 `forecast_unavailable` under Open-Meteo 429 — graceful, documented |
| `/api/geocode` | GET | Nominatim proxy (search + reverse), 1 req/s politeness, bilingual | `?q=` or `?lat=&lon=`, `?lang=en|ar` | 200 with results |
| `/api/analyses` | GET/POST | Optional saved analyses (list 10 / save / `?id=` load) | full result JSON on POST | 200 save `ok:true`, list correct |

Error contract observed: `400 invalid_json` / `invalid_input` (with zod issues), `404 crop_not_supported` (with `supportedCrops` list), `502 nasa_failed` / `forecast_unavailable` / `geocode_failed`, `500 server_error` / `save_failed`. Input ranges (lat ±90, lng ±180, month 1–12, day 1–366) are enforced.

---

## 7. NASA data sources and integrations

| Source | Usage | Implementation notes |
|---|---|---|
| **NASA POWER** `temporal/daily/point` (community AG) | 365-day window ending yesterday; 7 parameters: `T2M, T2M_MAX, T2M_MIN, PRECTOTCORR, RH2M, ALLSKY_SFC_SW_DWN, WS10M` | Server-side fetch, custom User-Agent, 45 s timeout, 1 retry (no retry on HTTP 400), fill `-999` excluded, solar MJ/m²/day → kWh/m²/day conversion, coverage tracking |
| **NASA POWER** `temporal/climatology/point` | 25-year monthly baseline for all 7 parameters | In-memory cache 6 h keyed on coordinates rounded to 0.01°; documented caveat that T2M_MAX/T2M_MIN here are climatological extremes, not means |
| **NASA POWER multi-year daily** | ~3 full years of daily data aggregated into month-of-year stats (mean daily max/min, observed extremes) | 60 s timeout; cached 6 h; complements the climatology endpoint |
| **NASA POWER recent range** | Last ~60 days summarised as "current conditions" with `latestObservationDate` surfaced | Optional dependency in planting/irrigation routes (`.catch(() => null)`) |
| **NASA GIBS** `wmts/epsg3857/best` | 3 verified layers: VIIRS SNPP true color (daily), MODIS Terra true color (daily), MODIS Terra L3 NDVI (16-day, snapped to composite start) | Client-side; CORS verified; tile-availability probe compares tile byte size; layer metadata (resolution, min dates, attribution) in `satellite.ts` |
| Open-Meteo | 7-day forecast (planting decision + early warnings) and elevation (FAO-56 pressure term) | Clearly labelled as *forecast*, never mixed with observations; optional and fails soft |
| Nominatim (OSM) | Search + reverse geocoding, bilingual `accept-language` | Server-side proxy with User-Agent and ≥1.1 s spacing per Nominatim policy |
| FAOSTAT (embedded) | Egypt national yields 2022–2024 (retrieved 2026-11-14, dated in code) | Static table with source URL and retrieval date |
| FAO documents | EcoCrop ranges, I&D Paper 33, FAO-56 Tables 11/12, Brouwer & Heibloem | Quoted ranges and verbatim Kc/stage rows, reference keys surfaced in Sources view |

No API keys are required anywhere. No simulated/demo data exists in the codebase; every value is either live NASA/Open-Meteo/OSM data, documented reference data (FAO/FAOSTAT/MALR), or user input — and the provenance is stated in the UI.

---

## 8. Database structure

Prisma + SQLite (`prisma/schema.prisma`), single optional model:

```prisma
model SavedAnalysis {
  id                String   @id @default(cuid())
  createdAt         DateTime @default(now())
  lat               Float
  lng               Float
  label             String
  soilType          String
  waterAvailability String
  season            String
  bestCrop          String
  bestCropEn        String
  bestCropAr        String
  bestScore         Int
  resultJson        String   // full AnalysisResult, stored verbatim
}
```

`db.ts` uses the standard global-Prisma-client pattern for dev hot-reload; `log: ['query']` is on in all environments (see issues). The app deliberately works without the DB ("Optional persistence" per schema comment).

---

## 9. Verification results (actually executed in this session)

| Check | Command | Result |
|---|---|---|
| Install | `bun install` | 832 packages, OK |
| Prisma | `bun run db:generate`, `bunx prisma db push` | client generated; DB created |
| Type check | `bunx tsc --noEmit` | **13 app errors** (+2 scaffolding files): 6 × `src/lib/planting.ts` (null-safety in score tuples), 5 × `AppShell.tsx` (Next 16 `dynamic()` loader typing), 2 × `PlantingView.tsx` (`result` possibly null) — masked by `ignoreBuildErrors: true` |
| Production build | `bun run build` | **PASS** — standalone output, 8 routes compiled, 10 static pages |
| Lint | `bunx eslint src` | 0 errors (note: many rules disabled in config) |
| Engine test (recommendation) | `bun scripts/test-engine.ts` | PASS with live NASA POWER data for Luxor |
| FAO-56 validation | `bun scripts/test-fao56.ts` | ALL CHECKS PASSED (vs FAO-56 Example 18, Uccle) |
| Planting test | `bun scripts/test-planting.ts` | ALL CHECKS PASSED |
| Risk/calendar test | `bun scripts/test-risk-calendar.ts` | PASS (requires `/tmp/analyze_test.json` fixture — had to be generated first) |
| Live API smoke test | dev server + curl on all 7 routes | all functional incl. validation and error paths |
| Secrets scan | env + archives | `.env` contains only `DATABASE_URL` (local file path). No keys, no tokens, no credentials anywhere |
| Placeholder scan | grep for TODO/FIXME/XXX | clean |

---

## 10. Potential issues (ranked)

**High priority**

1. **Type safety is suppressed globally** — `next.config.ts` sets `typescript.ignoreBuildErrors: true`, hiding the 13 real type errors above. Any new feature could introduce regressions that the compiler will never catch. Fix the 13 errors, then remove the flag.
2. **Sandbox scaffolding left in the GitHub deliverable** — `examples/websocket/` (imports `socket.io` — dependency missing → breaks `tsc`), `tests/*.sh` (reference `.zscripts/` which only exists in the original), `download/README.md`. All are dead weight; remove them.
3. **Brand inconsistency** — repo/README say "FieldShift"; UI strings, metadata, User-Agent, storage keys say "AgriWise". Decide the public name before release and apply it consistently (single change set: `translations.ts`, `layout.tsx` metadata, `nasa.ts`/route User-Agents, localStorage keys).

**Medium priority**

4. **No HTTP caching for the 365-day daily fetch** (`cache: "no-store"` on `/api/analyze` path) — every analysis refetches a year of daily data (multi-second). The 6 h in-memory cache covers climatology/multi-year/recent only. Caching daily data per rounded coordinate would cut repeat latency sharply.
5. **`db.ts` logs every Prisma query in production** (`log: ['query']` unconditionally) — noisy and slightly costly; gate on `NODE_ENV !== "production"`.
6. **No automated test runner/CI** — tests are manual Bun scripts; `test-risk-calendar.ts` hard-depends on a manually created `/tmp/analyze_test.json` fixture and fails without it.
7. **In-memory caches are per-process** — fine for single-instance deploys; a multi-instance or serverless deploy loses the 6 h caching benefit (correctness unaffected).
8. **Unused dependencies inflate install** — `next-auth`, `next-intl`, `@mdxeditor/editor`, `@dnd-kit/*`, `@tanstack/react-query`, `@tanstack/react-table`, `react-markdown`, `react-syntax-highlighter`, `embla-carousel-react`, `input-otp`, `vaul`, `uuid`, `z-ai-web-dev-sdk` are installed but not imported by app code.

**Low priority / notes**

9. `/api/analyses` GET silently returns an empty list on DB errors (designed for resilience, but masks DB failure); POST stores the payload without a size cap.
10. Geocode rate limiting uses a single process-local timestamp — adequate for demo, not for multi-instance.
11. Hash-based views are not individually SEO-indexable (inherent to the single-route SPA approach used to satisfy the sandbox constraint).
12. `SEASON_PLANTING_MONTHS` hard-codes the Egyptian season convention — correct for scope; should be revisited only if the target region expands.
13. The NASA POWER climatology endpoint's T2M_MAX/T2M_MIN semantics (extremes, not means) are correctly handled and documented, but worth remembering when extending.
14. Leaflet default marker images are avoided via custom `divIcon` (good); keep this pattern for any new map markers.

---

## 11. Recommendations and safest development approach

**Phase 0 — hygiene before new features (recommended, ~half a day):**
1. Fix the 13 TypeScript errors (mechanical: null-guards in `planting.ts` score tuples, loader typing in `AppShell.tsx`, null-narrowing for the two `PlantingView.tsx` helpers), then delete `ignoreBuildErrors` from `next.config.ts`.
2. Remove `examples/`, `tests/`, `download/` from the repo; keep `scripts/test-*.ts`.
3. Settle the name (Field Shift vs AgriWise) and apply it.
4. Optionally prune unused dependencies and gate Prisma query logging.

**Development conventions to preserve (these are the project's strengths):**
- Engines stay pure and dependency-free in `src/lib`, return `Bilingual` explainable output, never fabricate data, mark unavailable factors and lower confidence.
- New routes follow the existing contract: zod schema → `400 invalid_input` with issues; `NasaError` → mapped status; `crop_not_supported` → 404 with `supportedCrops`.
- New UI goes in `src/components/agriwise/views/`, dynamically imported in `AppShell`, uses the stores for cross-tool state, adds dictionary keys to both `en` and `ar` (type-enforced), and distinguishes live / historical / forecast / model-estimated data in the UI.
- Extend the crop database by appending `CropRecord` entries (engines, Kc table, stage templates, FAOSTAT rows and references must all be extended together — 6 files touch each new crop).

**Testing commands (exact, from repo root):**
```bash
bun install
cp .env.example .env
bun run db:generate && bunx prisma db push
bun run dev                      # http://localhost:3000
bunx tsc --noEmit                # type check (currently 13 errors)
bun run build                    # production build (standalone)
bunx eslint src                  # lint
bun scripts/test-fao56.ts        # FAO-56 vs Example 18
bun scripts/test-engine.ts       # recommendation engine, live NASA data
bun scripts/test-planting.ts     # planting advisor
bun scripts/test-risk-calendar.ts # requires /tmp/analyze_test.json (generate via /api/analyze output)
```

---

## 12. Conclusion

Field Shift is a coherent, well-engineered, honest-data application whose entire feature set is genuinely implemented — nothing is a stub. The safest path forward is: run the short Phase-0 hygiene pass, then develop new features strictly within the established conventions (pure engines + zod routes + dynamic views + bilingual output). The codebase is ready for feature work as-is; no rewrite or restructuring is needed.

**Analysis complete — stopping here as instructed. Awaiting the feature list.**
