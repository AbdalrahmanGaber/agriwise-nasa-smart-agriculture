# FieldShift

## Requirements
- Bun (recommended; the project includes `bun.lock`)
- Node.js compatible with the installed Next.js version

## Setup

1. Install dependencies:
   ```bash
   bun install
   ```
2. Create your local environment file:
   ```bash
   cp .env.example .env
   ```
   On Windows PowerShell, use:
   ```powershell
   Copy-Item .env.example .env
   ```
3. Generate the Prisma client and initialize the local database:
   ```bash
   bun run db:generate
   bun run db:push
   ```
4. Start the development server:
   ```bash
   bun run dev
   ```

Open http://localhost:3000.

## Build

```bash

bun run build
```

## Notes
- `.env` and local database files are intentionally excluded. Do not commit credentials or private data.
- Configure any required API keys in your local `.env` file; add only safe variable names and placeholders to `.env.example`.
