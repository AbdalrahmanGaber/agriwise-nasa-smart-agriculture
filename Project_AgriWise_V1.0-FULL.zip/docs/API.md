# Field Shift — API Documentation

All endpoints are Next.js App Router routes (`src/app/api/*/route.ts`).
Requests and responses are JSON. External services (NASA POWER, NASA GIBS,
Open-Meteo, Nominatim) are called **server-side only** — the client never
talks to them directly.

Every endpoint follows the same error contract:

| Status | `error` value | Meaning |
|---|---|---|
| 400 | `invalid_json` / `invalid_input` | Body/query failed zod validation (`issues` included) |
| 404 | `crop_not_supported` | Crop text could not be resolved (`supportedCrops` included) |
| 502 | `nasa_failed` / `forecast_unavailable` / `geocode_failed` | Upstream service failed after retries |
| 500 | `server_error` / `save_failed` | Unexpected server error |

Bilingual fields use the shape `{ en: string, ar: string }` throughout.

---

## POST /api/analyze

Full farm analysis: fetches 365 days of NASA POWER daily data (community AG),
aggregates a monthly climatology + summary, and runs the explainable
recommendation engine.

**Body**

```json
{
  "location": {
    "lat": 25.6872,
    "lng": 32.6396,
    "label": "Luxor, Egypt",
    "source": "search",
    "accuracy": 15
  },
  "farm": {
    "soilType": "loam",
    "waterAvailability": "abundant",
    "season": "winter",
    "farmSize": 2,
    "sizeUnit": "acres",
    "irrigationMethod": "flood",
    "notes": ""
  }
}
```

**Response** — `AnalysisResult`: `meta` (provider, period, parameters, units,
coordinates), `location`, `farm`, `monthly[12]` (per-month climatology with
coverage), `summary` (annual + extremes + seasons), `crops[]` (ranked, with
per-factor 0–100 scores, weights, reasons, limitations, irrigation gap,
`windowMonths`), `engine` (weights + methodology + confidence), `generatedAt`.

---

## POST /api/planting

Smart Planting Time Advisor. Fetches, in parallel:

- NASA POWER 25-year monthly climatology (cached 6 h),
- ~3 years of NASA POWER daily observations aggregated per month-of-year (cached 6 h),
- last ~60 days of observations (optional; failure tolerated),
- a real 7-day Open-Meteo forecast (optional; failure tolerated → returned as `null`).

**Body**

```json
{
  "crop": "sugarcane",
  "lat": 25.6872,
  "lng": 32.6396,
  "label": "Luxor",
  "currentMonth": 11,
  "variety": ""
}
```

**Response** — `PlantingResult`: `crop` (documented requirements + references),
`months[12]` (per-month `score`, `cycleScore`, `plantingScore`, classification
`suitable|caution|unsuitable`, factor scores, 25-yr/3-yr climate values,
cycle rainfall), `seasons[4]` (per-season best month + score),
`computed` (recommended season, best month, alternatives, caution/unsuitable
lists), `decision` (`plant_now` | `wait` | `not_recommended` + basis + reasons
+ warnings + `targetMonth`), `current` (recent observations with
`latestObservationDate`, forecast block labelled `Open-Meteo` when available,
temperature/rainfall explanations, heat/cold stress notes), `methodology`,
`meta`.

Unknown crop → `404` with `supportedCrops`.

---

## POST /api/irrigation

Smart Irrigation Advisor. FAO-56 Penman–Monteith ETo (monthly climatology +
recent-observation bases; elevation from Open-Meteo, cached for the process
lifetime) → ETc = Kc(stage) × ETo with documented FAO-56 Table 11/12 values.

**Body**

```json
{
  "crop": "sugarcane",
  "lat": 25.6872,
  "lng": 32.6396,
  "label": "Luxor",
  "growthStage": "mid",
  "soilType": "loam",
  "waterAvailability": "abundant",
  "irrigationMethod": "flood",
  "currentMonth": 11,
  "currentDayOfYear": 318
}
```

**Response** — `IrrigationResult`: `eto` (monthly + recent ETo and elevation,
`null` when the elevation service is unreachable — never substituted),
`etc` (stage ETo/ETc, seasonal peak, water need), `factors` (temperature /
solar / humidity / rainfall influences with real measured values),
`guidance` (general guidance, factors ↑/↓ demand, water-management
recommendations), `disclosures` (data availability + limitations),
`meta`.

---

## POST /api/yield

Expected Crop Yield reference. Returns FAOSTAT Egypt national yields
(2022–2024, embedded with source + retrieval date), area arithmetic
(feddan = 0.42 ha) and climate risk factors positioned against the crop
cycle. No field-specific prediction is claimed.

**Body**

```json
{
  "crop": "wheat",
  "lat": 25.6872, "lng": 32.6396, "label": "Luxor",
  "area": 2, "areaUnit": "feddan",
  "variety": "",
  "plantingMonth": 11,
  "soilType": "loam", "waterAvailability": "abundant",
  "irrigationMethod": "flood", "growthStage": "mid"
}
```

**Response** — `YieldResult`: `reference` (national min/mean/max t/ha by
year + FAOSTAT source + retrieval date), `production` (estimated range for
the given area, labelled as reference-based estimate), `factors[]` (climate
risks relevant to the crop cycle with measured values), `disclaimer`,
`meta`.

---

## GET /api/forecast

Real 7-day Open-Meteo forecast for early warnings (30-min server cache).
`?lat=<float>&lng=<float>`.

**Response**: `{ days[7] (date, tmax, tmin, precip, windMax in m/s),
provider: "Open-Meteo", model, retrievedAt, provenance: "forecast" }`.

Failure → `502 forecast_unavailable` (never estimated data).

---

## GET /api/geocode

Nominatim proxy (politeness: identified User-Agent, ≥1.1 s spacing).

- Search: `?q=Luxor&lang=en|ar` → `{ results: [{lat, lng, label, name}] }`
- Reverse: `?lat=..&lon=..&lang=en|ar` → `{ label, full }` (`label: null` when unknown)

---

## GET/POST /api/analyses

Optional persistence (Prisma + SQLite). The app works fully without it.

- `GET /api/analyses` → latest 10 saved analyses (metadata only)
- `GET /api/analyses?id=...` → full stored result
- `POST /api/analyses` with `{ result: AnalysisResult }` → `{ id, ok: true }`

---

## Caching

| Data | Cache | TTL |
|---|---|---|
| NASA POWER 365-day daily (`/api/analyze`) | in-memory per rounded coordinate | 6 h |
| NASA POWER 25-yr climatology | in-memory | 6 h |
| NASA POWER multi-year daily | in-memory | 6 h |
| Open-Meteo 7-day forecast | in-memory | 30 min |
| Open-Meteo elevation | in-memory | process lifetime |
| Geocode | none (rate-limited instead) | — |
